<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $id = $_POST['id'];
    $fleet_id = $_POST['fleet_id'];
    $station = $_POST['station'];
    $amount = $_POST['amount'];
    $driver = $_POST['driver'];
    $timestamp = $_POST['timestamp'];

    require_once 'connect.php';
    
    $sql = "INSERT INTO dufleet_fuel (fuel_id, fleet_id, station, amount, driver_name, timestamp)  VALUES ('$id', '$fleet_id', '$station', '$amount', '$driver','$timestamp')";

    if ( mysqli_query($con, $sql) ) {
        
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($con);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";
        $result["query"] = $sql;

        echo json_encode($result);
        mysqli_close($con);
    }
    
}
    


?>