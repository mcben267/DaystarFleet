<?php

if ($_SERVER['REQUEST_METHOD']=='GET') {

    require_once 'connect.php';

    $query = "SELECT * from dufleet_parcel";
    $result = mysqli_query($con, $query);
    $json_array = array();
    
    while($row = mysqli_fetch_assoc($result)) {
        $json_array[] =$row;
    }
    
	if(isset($result) && isset($json_array)){
		print(json_encode($json_array));
	}else{   
	    echo 'error';
	}
	
	 mysqli_close($con);
	
}

?>