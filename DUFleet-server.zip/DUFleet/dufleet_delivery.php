<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {
    
    $systemDate = $_POST['date'];
    $id = $_POST['id'];

    require_once 'connect.php';

    $query = "UPDATE dufleet_parcel SET parcel_status ='Delivered', delivery_date = '$systemDate'
                WHERE parcel_id = '$id';
";

	if(mysqli_query($con, $query)){
    		    
     		 $reponse ["success"]="1";
    		    $reponse ["message"]="update dailed";
    		    //$reponse ["message"]="query: ".$query;
    		    
    		    echo json_encode($reponse);
     			
    		}else{
    		    $reponse ["success"]="0";
    		    $reponse ["message"]="update dailed";
    		    $reponse ["message"]="query: ".$query;
    		    
    		    echo json_encode($reponse);
    		}
	 mysqli_close($con);
	
}
?>