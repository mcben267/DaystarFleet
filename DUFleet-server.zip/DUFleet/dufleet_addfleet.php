<?php

if($_SERVER['REQUEST_METHOD'] == 'POST') {

    $id = $_POST['id'];
    $type = $_POST['type'];
    $capacity = $_POST['capacity'];
    $reg = $_POST['reg'];
    $com_date = $_POST['com_date'];
    $mileage = $_POST['mileage'];
    $chassis = $_POST['chassis'];
    $image = $_POST['image'];
    $path = "images/$id.jpeg";
    $finalPath = "https://myloanapp.000webhostapp.com/DUFleet/".$path;

    require_once 'connect.php';

    $sql = "INSERT INTO dufleet_fleet (fleet_id, type, capacity, reg_no, commission_date, chaise_no, start_mileage, image) VALUES ('$id','$type','$capacity','$reg','$com_date','$chassis','$mileage','$finalPath')";

    if (mysqli_query($con, $sql)) {
        
        if ( file_put_contents( $path, base64_decode($image) ) ) {
            
            $result['success'] = "1";
            $result['message'] = "success";
            $result['query'] = "sql ".$sql;
            echo json_encode($result);
            mysqli_close($con);

        }

    }else{
        $result['success'] = "0";
        $result['message'] = "success";
        $result['query'] = "sql ".$sql;
        echo json_encode($result);
        mysqli_close($con);
    }

}

?>