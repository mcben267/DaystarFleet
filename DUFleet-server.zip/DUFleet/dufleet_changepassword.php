<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $email = $_POST['email'];
    $newPassword = $_POST['newPassword'];
    $oldPassword = $_POST['oldPassword'];

    $password_hash = password_hash($newPassword, PASSWORD_DEFAULT);

    require_once 'connect.php';
    
    $query = "select * from dufleet_users where email = '$email'";
	$recordExists = mysqli_query($con, $query);
	
	if(isset($recordExists)){
	    
	    if ( mysqli_num_rows($recordExists) === 1 ) {
        
            $row = mysqli_fetch_assoc($recordExists);

            if ( password_verify($oldPassword, $row['password']) ) {
                
                $query2 = "UPDATE dufleet_users SET password = '$password_hash' WHERE email = '$email'";
    
                if ( mysqli_query($con, $query2) ) {
                    
                    $result["success"] = "1";
                    $result["message"] = "success";
                    echo json_encode($result);
                    mysqli_close($con);
            
                } else {
            
                    $result["success"] = "0";
                    $result["message"] = "error";
                    $result["message"] = "query: ".$query2;
            
                    echo json_encode($result);
                    mysqli_close($con);
                }
                
            }else{
                
                $result["success"] = "2";
                $result["message"] = "Do not match";
                echo json_encode($result);
                mysqli_close($con);
    
            }
	    }
	
	}else{

	    $result["success"] = "0";
        $result["message"] = "Invalid";
        $result["message"] = "query: ".$query;
        echo json_encode($result);
        mysqli_close($con);
    
    }
}

?>