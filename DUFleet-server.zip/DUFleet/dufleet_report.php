<?php

if ($_SERVER['REQUEST_METHOD']=='GET') {

    require_once 'connect.php';

    $query = "SELECT COUNT(dufleet_fleet.start_mileage) as fleet, SUM(dufleet_revenue.amount) as revenue, SUM(dufleet_fuel.amount) as fuel FROM dufleet_fleet,dufleet_revenue,dufleet_fuel";
    $result = mysqli_query($con, $query);

    while($row = mysqli_fetch_assoc($result)) {
        $index['fleet_no'] =$row['fleet'];
        $index['revenue'] =$row['revenue'];
        $index['fuel'] =$row['fuel'];
    }
    
	if(isset($result) && isset($index)){
		print(json_encode($index));
	}else{   
	    echo "error";
	}
	
	 mysqli_close($con);
	
}

?>