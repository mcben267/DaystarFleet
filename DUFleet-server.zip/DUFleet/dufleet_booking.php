<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {

    require_once 'connect.php';

    $query = "SELECT * from dufleet_booking ORDER BY date_stamp DESC";
    $result = mysqli_query($con, $query);
    $json_array = array();
    
    while($row = mysqli_fetch_assoc($result)) {
        $json_array[] =$row;
    }
    
	if(isset($result) && isset($json_array)){
		print(json_encode($json_array));
	}else{   
	    echo "error";
	}
	
	 mysqli_close($con);
	
}
?>