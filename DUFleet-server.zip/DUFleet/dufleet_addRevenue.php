<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $revenue_id = $_POST['revenue_id'];
    $fleet_id = $_POST['fleet_id'];
    $mpesa_ref = $_POST['mpesa_ref'];
    $amount = $_POST['amount'];
    $conductor_name = $_POST['conductor_name'];
    $timestamp = $_POST['timestamp'];

    require_once 'connect.php';
    

    $sql = "INSERT INTO dufleet_revenue (revenue_id, fleet_id, mpesa_ref, amount, conductor_name, timestamp ) VALUES ('$revenue_id', '$fleet_id', '$mpesa_ref', '$amount', '$conductor_name','$timestamp')";

    if ( mysqli_query($con, $sql) ) {
        
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($con);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";
        //$result["query"] = $sql;

        echo json_encode($result);
        mysqli_close($con);
    }
    
}
    


?>