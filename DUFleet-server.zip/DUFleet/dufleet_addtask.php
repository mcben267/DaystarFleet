<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $id = $_POST['id'];
    $title = $_POST['title'];
    $message = $_POST['message'];
    $status = $_POST['status'];
    $timestamp = $_POST['timestamp'];

    require_once 'connect.php';
    
    $sql = "INSERT INTO dufleet_task (task_id, user_id,title, task_status, details, timestamp) VALUES (NULL,'$id', '$title', '$status', '$message', '$timestamp')";

    if ( mysqli_query($con, $sql) ) {
        
        $result["success"] = "1";
        $result["message"] = "success";

        echo json_encode($result);
        mysqli_close($con);

    } else {

        $result["success"] = "0";
        $result["message"] = "error";
        $result["query"] = $sql;

        echo json_encode($result);
        mysqli_close($con);
    }
    
}
    


?>