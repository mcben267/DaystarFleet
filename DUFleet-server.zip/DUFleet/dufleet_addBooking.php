<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $booking_id = rand();
    $full_name = $_POST['full_name'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $department = $_POST['department'];
    $note = $_POST['note'];
    $booking_date = $_POST['booking_date'];
    $time= time();
    $date_stamp = date("y-m-d H:i:s",$time); 

    require_once 'connect.php';
    
    function sendEmail($email_x,$full_name_x,$booking_date_x) {
	    $to = $email_x;
	    $subject ="Transport Booking - $booking_date_x";
	    $message = "Hello $full_name_x,\n \rWe have received your transport booking,\n
	    \rWe will call you as soon as possible.\nPlease call +254711545036 incase you don't get a response in 48 hours.
	    \nRegards, \nJohn M.G\nTransport Coordinator";
	    $headers = 'From: cliffdevops@gmail.com';
	    
          if( mail($to,$subject,$message,$headers)){

          } else{
	       
          }
          
          header("Location: https://myloanapp.000webhostapp.com/", true, 301);
            exit();
          
	}

    $sql = "INSERT INTO dufleet_booking (booking_id, full_name, mobile, email, department, note, booking_date, date_stamp) VALUES ('$booking_id', '$full_name', '$mobile', '$email','$department', '$note','$booking_date','$date_stamp')";

    if ( mysqli_query($con, $sql) ) {
        sendEmail($email,$full_name,$booking_date);
        // header("Location: https://myloanapp.000webhostapp.com/", true, 301);
        // exit();
        
        
    } else {
        $result["success"] = "0";
        $result["message"] = "error";
        //$result["query"] = $sql;
        echo json_encode($result);
        mysqli_close($con);
    }
    
}

?>