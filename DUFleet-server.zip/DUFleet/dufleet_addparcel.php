<?php

if($_SERVER['REQUEST_METHOD'] == 'POST') {

    $parcel_id = $_POST['parcel_id'];
    $sender_name = $_POST['sender_name'];
    $sender_mobile = $_POST['sender_mobile'];
    $receiver_name = $_POST['receiver_name'];
    $receiver_mobile = $_POST['receiver_mobile'];
    $receiver_address = $_POST['receiver_address'];
    $parcel_category = $_POST['parcel_category'];
    $send_date = $_POST['send_date'];
    $parcel_destination = $_POST['parcel_destination'];
    $parcel_origination = $_POST['parcel_category'];
    $staffID = $_POST['staffID'];
    $image = $_POST['image'];
    $path = "images/$parcel_id.jpeg";
    $finalPath = "https://myloanapp.000webhostapp.com/DUFleet/".$path;

    require_once 'connect.php';

    $sql = "INSERT INTO dufleet_parcel ( parcel_id, sender_name, sender_mobile, receiver_name, receiver_mobile, receiver_address, parcel_image, parcel_category, parcel_status, send_date, delivery_date, parcel_destination, parcel_origination ) VALUES ('$parcel_id', '$sender_name', '$sender_mobile', '$receiver_name', '$receiver_mobile', '$receiver_address', '$finalPath', '$parcel_category', 'In-transit', '$send_date', 'NULL', '$parcel_destination', '$parcel_origination')";

    if (mysqli_query($con, $sql)) {
        
        if ( file_put_contents( $path, base64_decode($image) ) ) {
            
            $result['success'] = "1";
            $result['message'] = "success";
            //$result['query'] = "sql ".$sql;
            echo json_encode($result);
            mysqli_close($con);

        }

    }else{
        $result['success'] = "0";
        $result['message'] = "success";
        $result['query'] = "sql ".$sql;
        echo json_encode($result);
        mysqli_close($con);
    }

}

?>