<?php

define('HOST', 'localhost');
define('USER', 'id13667764_host');
define('PASSWORD', 'Qwerty-12345');
define('DB', 'id13667764_myloandb');

$con = mysqli_connect(HOST, USER, PASSWORD, DB) or die("Unable to Connect");

?>