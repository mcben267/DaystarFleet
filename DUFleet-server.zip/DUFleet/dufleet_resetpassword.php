<?php 
    
    
    if ($_SERVER['REQUEST_METHOD']=='POST') {

    $email = $_POST['email'];
    $token = $_POST['token'];
    $pass= password_hash($token, PASSWORD_DEFAULT);

    require_once 'connect.php';

	function sendEmail($femail,$fcode) {
	    $to = $femail;
	    $subject ='DU Fleet App: Password Rest';
	    $message = "Hello \n \n\rYour password has been reset successfully.\nPassword Rest token: $fcode\n\nRegards, \nDev Team";
	    $headers = 'From: cliffdevops@gmail.com';
	    
          if( mail($to,$subject,$message,$headers)){
              
              $reponse ["success"]="1";
              $reponse ["message"]="mail sent";
              
              echo json_encode($reponse);
	            
          } else{
              $reponse ["success"]="0";
	          $reponse ["message"]="mail failed";
	          echo json_encode($reponse);
          }
	}

    if($email == ''){
        
    	$reponse ["success"]="0";
    	$reponse ["message"]="User email empty";
    	
    	echo json_encode($reponse);
    	
    }else{
        
        $query = "select * from dufleet_users where email = '$email'";
    	$recordExists = mysqli_fetch_array(mysqli_query($con, $query));
    	
    	if(isset($recordExists)){
    	    
    		$query = "UPDATE dufleet_users SET password = '$pass' WHERE email = '$email'";
    		if(mysqli_query($con, $query)){
    		    
     			sendEmail($email,$token);
     			
    		}else{
    		    $reponse ["success"]="0";
    		    $reponse ["message"]="update dailed";
    		    $reponse ["message"]="query: ".$query;
    		    
    		    echo json_encode($reponse);
    		}
    	}else{
    	     $reponse ["message"]="email does not exist";
    		 $reponse ["message"]="query: ".$query;
    		    
    		 echo json_encode($reponse);
    	}
    	
    	mysqli_close($con);
    }
}

?>