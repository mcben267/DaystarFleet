<?php

if ($_SERVER['REQUEST_METHOD']=='GET') {

    require_once 'connect.php';

    $query = "SELECT COUNT(fleet_id) as total FROM dufleet_fleet";
    $result = mysqli_query($con, $query);

    while($row = mysqli_fetch_assoc($result)) {
        $index['amount'] =$row['total'];

    }
    
	if(isset($result) && isset($index)){
	    $index ['success'] = '1';
		print(json_encode($index));
	}else{   
	    $index ['success'] = '0';
	    $index ['message'] = 'error';
	    print(json_encode($index));

	}
	
	 mysqli_close($con);
	
}

?>