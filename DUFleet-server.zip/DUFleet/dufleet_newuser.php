<?php

if ($_SERVER['REQUEST_METHOD'] =='POST'){

    $staff_id = $_POST['user_id'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $account = $_POST['type'];
   // $code = $_POST['password'];
    $code = "Test1234";
    $pass= password_hash($code, PASSWORD_DEFAULT);

    require_once 'connect.php';
    
    function sendEmail($email_x,$user_id_x,$name_x,$code_x) {
	    $to = $email_x;
	    $subject ='Daystar Fleet App';
	    $message = "Hello $name_x \n\rWelcome on board.\n\nUsername: $user_id_x \nPassword: $code_x \n\nRegards, \nDev Team";
	    $headers = 'From: cliffdevops@gmail.com';
	    
          if( mail($to,$subject,$message,$headers)){
              
              $reponse ["success"]="1";
              $reponse ["message"]="mail sent";
              echo json_encode($reponse);
	            
          } else{
             $reponse ["success"]="0";
	         $reponse ["message"]="mail failed";
	         echo json_encode($reponse);
          }
	}
    

    $sql = "INSERT INTO dufleet_users (staff_id, name, surname, mobile, email, password, account) VALUES ('$staff_id', '$name', '$surname', '$mobile', '$email','$pass','$account')";
    
    $query = "INSERT INTO `dufleet_employees` (`staff_id`, `profile_pic`, `name`, `surname`, `role`, `mobile`, `email`, `tax_pin`, `national_id`, `license`, `insurance_status`, `insurance_policy`, `blood_group`, `medical_state`) VALUES ('$staff_id', 'null', '$name', '$surname', '$account', '$mobile', 'null', 'null', 'null', 'null', 'null', 'null', 'null', 'null')  ";

    if ( mysqli_query($con, $sql) ) {
        //sendEmail($email,$staff_id,$name,$code);
        
        if( mysqli_query($con, $query)){
            sendEmail($email,$staff_id,$name,$code);
        }else{
            $result["success"] = "0";
            $result["message"] = "failed";
            echo json_encode($result);
        }
        
    } else{
        $result["success"] = "0";
        $result["message"] = "failed";
        $result["email"] = "false";
        $result["query"] = ">> ".$sql;
        echo json_encode($result);
    }
    
    mysqli_close($con);
}

?>