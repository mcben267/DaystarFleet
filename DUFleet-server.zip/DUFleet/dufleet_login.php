<?php

if ($_SERVER['REQUEST_METHOD']=='POST') {

    $staff_id = $_POST['staff_id'];
    $password = $_POST['password'];

    require_once 'connect.php';
    
    $query = "select * from dufleet_users where staff_id = '$staff_id' ";
    $response = mysqli_query($con, $query);
    
    if ( mysqli_num_rows($response) === 1 ) {
        
        $row = mysqli_fetch_assoc($response);

        if ( password_verify($password, $row['password']) ) {
            
            $result['user_id'] = $row['staff_id'];
            $result['name'] = $row['name'];
            $result['surname'] = $row['surname'];
            $result['email'] = $row['email'];
            $result['user'] = $row['account'];
            $result['mobile'] = $row['mobile'];
            
            $result['success'] = "1";
            $result['message'] = "success";
            echo json_encode($result);

            mysqli_close($con);

        } else {

            $result['success'] = "0";
            $result['message'] = "error";
            $result['query'] = ">> ".$query;
            echo json_encode($result);

            mysqli_close($con);

        }

    }

}

?>